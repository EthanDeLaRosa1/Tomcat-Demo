package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class DbCheckServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String host = System.getenv("DB_HOST");
        String port = System.getenv("DB_PORT");
        String db   = System.getenv("DB_NAME");
        String user = System.getenv("DB_USER");
        String pass = System.getenv("DB_PASSWORD");

        String url = "jdbc:postgresql://" + host + ":" + port + "/" + db;

        resp.setContentType("text/plain");

        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            resp.setStatus(500);
            resp.getWriter().println("Postgres JDBC driver NOT found in runtime classpath ❌");
            resp.getWriter().println(e.toString());
            return;
        }

        try (Connection conn = DriverManager.getConnection(url, user, pass);
             PreparedStatement ps = conn.prepareStatement("SELECT 1");
             ResultSet rs = ps.executeQuery()) {

            rs.next();
            resp.getWriter().println("DB connection OK ✅ (SELECT 1 returned " + rs.getInt(1) + ")");
        } catch (Exception e) {
            resp.setStatus(500);
            resp.getWriter().println("DB connection FAILED ❌");
            resp.getWriter().println(e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }
}
